"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

    Author: Rajagopal Senthil Kumar
    Created Date:  01-Sep-2017
    Modified Date: 07-Sep-2017
    Purpose: Python program to read images and text from PDF 

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

import time
from internal import Internal
import tweepy
from tweepy import OAuthHandler
import json
from tweepy import Stream
from tweepy.streaming import StreamListener
import os
import re


def saveAsJsonFile(tweet,file_name):
     json_file=open(file_name,"w+")
     json.dump(tweet,json_file)

def printIt(tweet):
    print(json.dumps(tweet))


class TweetListener(StreamListener):
   
   def __init__(self, file_name):
        self.stream_file=file_name

   def on_data(self, data):
        try:
         #   file_name="C:\\Program360\\Sample\\MyTweet1.json"
            with open(self.stream_file, 'a') as f:
                f.write(data)
                return True
        except BaseException as e:
            print("Error on_data: %s" % str(e))
        return True
 
   def on_error(self, status):
        print(status)
        return True
 

 
class TweetReader(Internal):
    def __init__(self):
        self._consumer_key= '9GFD5hVQUKQlXzakv2poR0Eo1'
        self._consumer_secret = '5fIdPGwBHdeX8uOZs1Tow2UVOSQsOtcfcuh3BXzAeji0MN28wv'
        self._access_token = '244175665-w8NZbraXnyjfW9GsoKVy9PUcExwqoFqLQ6ZuCqNg'
        self._access_secret = 'pcIgFUUVjQ9hKY5XAiWKEtGuraFUkBmQORRVrLsqZeLWv'
        self.tweet_auth=OAuthHandler(self._consumer_key, self._consumer_secret)
        self.tweet_auth.set_access_token(self._access_token, self._access_secret)
        self.tweet_api=tweepy.API(self.tweet_auth)
        self.emoticons_str = r"""(?:[:=;] # Eyes [oO\-]? # Nose (optional) [D\)\]\(\]/\\OpP] # Mouth)"""
        self.regex_str = [self.emoticons_str, r'<[^>]+>', # HTML tags
                                r'(?:@[\w_]+)', # @-mentions
                                r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)", # hash-tags
                                r'http[s]?://(?:[a-z]|[0-9]|[$-_@.&amp;+]|[!*\(\),]|(?:%[0-9a-f][0-9a-f]))+', # URLs
                                r'(?:(?:\d+,?)+(?:\.?\d+)?)', # numbers
                                r"(?:[a-z][a-z'\-_]+[a-z])", # words with - and '
                                r'(?:[\w_]+)', # other words
                                r'(?:\S)' # anything else
                            ]

        self.tokens_re = re.compile(r'('+'|'.join(self.regex_str)+')', re.VERBOSE | re.IGNORECASE)
        self.emoticon_re = re.compile(r'^'+self.emoticons_str+'$', re.VERBOSE | re.IGNORECASE)

    def tokenize(self,s):
         return self.tokens_re.findall(s)


    def preprocess(self,s, lowercase=False):
        tokens = tokenize(s)
        if lowercase:
            self.tokens = [token if self.emoticon_re.search(token) else token.lower() for token in tokens]
        return tokens

    def readTimeline(self):
        for latesttweet in tweepy.Cursor(self.tweet_api.home_timeline).items(10):
            print(latesttweet.text)

    def saveMyTimelineToJson(self,file_name):
        for latesttweet in tweepy.Cursor(self.tweet_api.home_timeline).items(10):
            saveAsJsonFile(latesttweet._json,file_name)

    def readFollowers(self):
       for friend in tweepy.Cursor(self.tweet_api.friends).items():
             printIt(friend._json)
    
    def readTweets(self):
        for mytweet in tweepy.Cursor(self.tweet_api.user_timeline).items():
            printIt(mytweet._json)


    def saveMyTweetsToJson(self,file_name):
        for mytweet in tweepy.Cursor(self.tweet_api.user_timeline).items():
           saveAsJsonFile(mytweet._json,file_name)


    def listenToThis(self,file_name,filter_value):
        twitter_stream = Stream(self.tweet_auth, TweetListener(file_name))
        try:
            twitter_stream.filter(track=filter_value)
        except Exception as ex:
           result=  None

    def displayTweetFromJson(self,file_name):

        with open(file_name, 'r') as f:
            line = f.readline() 
            tweet = json.loads(line) 
            print(json.dumps(tweet, indent=4)) # pretty-print

 



class TweetlistenerX(StreamListener):
    
    def __init__(self, file_name,start_time, time_limit=60):

        self.stream_file = file_name
        self.time = start_time
        self.limit = time_limit
        self.tweet_data = []

    def on_data(self, data):

        saveFile = io.open(self.stream_file, 'a', encoding='utf-8')

        while (time.time() - self.time) < self.limit:
            try:
                self.tweet_data.append(data)
                return True
 
            except BaseException as e:
                print( 'failed ondata,', str(e))
                time.sleep(5)
                pass
 
        saveFile = io.open(self.stream_file, 'w', encoding='utf-8')
        saveFile.write(u'[\n')
        saveFile.write(','.join(self.tweet_data))
        saveFile.write(u'\n]')
        saveFile.close()
        exit()






 





